# بناء التطبيق من الهاتف

1. فك ضغط المشروع على هاتفك أو احتفظ به في مجلد التنزيلات.
2. افتح مستودع GitHub من المتصفح.
3. ارفع محتويات `coptic_calendar_app` إلى جذر المستودع، بما فيها `.github` إن أمكن إظهار الملفات المخفية.
4. من Actions افتح `Build Coptic Calendar APK` ثم اختر Run workflow.
5. بعد ظهور علامة النجاح، افتح تفاصيل التشغيل ونزّل `coptic-calendar-v3-agricultural-debug-apk`.
6. فك ضغط الملف الناتج وثبّت `app-debug.apk`. قد يطلب Android السماح بالتثبيت من هذا المصدر.

إذا لم يظهر مجلد `.github` عند الرفع، فعّل إظهار الملفات المخفية أو ارفع ملف workflow يدويًا إلى `.github/workflows/build-apk.yml`.
