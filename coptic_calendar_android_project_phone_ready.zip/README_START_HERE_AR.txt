ابدأ من هنا:
1) فك ضغط coptic_calendar_android_project_phone_ready.zip.
2) اقرأ الملف coptic_calendar_app/BUILD_FROM_PHONE_AR.md.
3) ارفع محتويات coptic_calendar_app إلى مستودع GitHub جديد مع المجلد المخفي .github.
4) شغّل GitHub Actions لبناء APK ثم نزّل Artifact.
